export default {
    items: [
        ['', '']
    ],
    tipoFlujo: 0,
    ordenFirmantes: false,
    signers: [{
        tipo: '',
        nombre: '', 
        correo: '',
        annotations: [],
    }]
};