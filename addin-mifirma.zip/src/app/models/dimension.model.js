export class Dimension {
  
    constructor(width, height) {
      this.width = width;
      this.height = height;
    }
  }
  