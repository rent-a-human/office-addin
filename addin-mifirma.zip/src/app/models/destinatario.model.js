export class Destinatario {

    constructor(nombre, correo) {
        this.name = nombre;
        this.email = correo;

    }
}
